===========
Description
===========

"csvsimple" provides a simple tool to handle CSV data.

See example on Github : 

https://github.com/denis-beurive/csvsimple/blob/master/examples/ex.py

Requirement
===========

This module requires Python 3 or greater.

See this module on pypi.python.org
==================================

http://pypi.python.org/pypi?:action=display&name=csvsimple

Installation from source
========================

Get the source on Github: https://github.com/denis-beurive/csvsimple

    python setup.py sdist

    python setup.py install


