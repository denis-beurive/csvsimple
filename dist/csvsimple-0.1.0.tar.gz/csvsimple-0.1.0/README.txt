===========
Description
===========

"csvsimple" provides a simple tool to handle CSV data.

See example on Github : 

https://github.com/denis-beurive/pyCSV/blob/master/examples/ex.py

Requirement
===========

This module requires Python 3 or greater.

Installation from source
========================

Get the source on Github: https://github.com/denis-beurive/pyCSV

    python setup.py sdist

    python setup.py install


