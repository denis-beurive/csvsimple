===========
Towel Stuff
===========

CSV provides a simple tool to handle CSV data.

   from cvs.base import Csv

   csv = Csv(['field1', 'field2', 'field3'])
   cvs.add([12, 34, 56])
   csv.add([34, 78, 99])
   ...



